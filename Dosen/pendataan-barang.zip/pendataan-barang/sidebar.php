<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="dashboard.php">Sistem Barang</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav me-auto">
            <a href="/pendataan-barang/dashboard.php" class="list-group-item">Dashboard</a>
            <a href="/pendataan-barang/barang/index.php" class="list-group-item">Barang</a>
            <a href="/pendataan-barang/logout.php" class="list-group-item text-danger">Logout</a>
            </ul>
        </div>
    </div>
</nav>
